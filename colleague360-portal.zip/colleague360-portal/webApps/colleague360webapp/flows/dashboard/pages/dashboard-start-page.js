/**
 * Copyright (c) 2024, 2026 Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define([], function () {
  'use strict';

  class PageModule {
    constructor() {}

    /**
     * Get icon for action type
     * @param {string} type - Action type
     * @returns {string} Icon class
     */
    getActionIcon(type) {
      const icons = {
        approval: 'oj-ux-ico-check-circle',
        learning: 'oj-ux-ico-education',
        expense: 'oj-ux-ico-credit-card',
        benefits: 'oj-ux-ico-heart',
        profile: 'oj-ux-ico-contact',
        timeoff: 'oj-ux-ico-clock',
        performance: 'oj-ux-ico-trending-up'
      };
      return icons[type] || 'oj-ux-ico-alert-circle';
    }

    /**
     * Format date for display
     * @param {string} dateString - ISO date string
     * @returns {string} Formatted date
     */
    formatDate(dateString) {
      if (!dateString) return '';
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    }

    /**
     * Load KPI data (placeholder for API integration)
     * @returns {Promise} KPI data
     */
    async loadKPIData() {
      // This would typically call a REST service
      console.log('Loading KPI data...');
      return Promise.resolve();
    }

    /**
     * Refresh dashboard data
     */
    refreshDashboard() {
      console.log('Refreshing dashboard...');
      // Trigger data refresh
    }
  }

  return PageModule;
});
