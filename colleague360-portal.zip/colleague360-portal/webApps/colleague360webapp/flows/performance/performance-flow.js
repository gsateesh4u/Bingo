define([], function() {
  'use strict';
  class PerformanceFlowModule {
    constructor() {}
  }
  return PerformanceFlowModule;
});
