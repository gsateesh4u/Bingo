define([], function() {
  'use strict';
  class PerformanceStartPageModule {
    constructor() {}
  }
  return PerformanceStartPageModule;
});
