define([], function() {
  'use strict';
  class LearningStartPageModule {
    constructor() {}
  }
  return LearningStartPageModule;
});
