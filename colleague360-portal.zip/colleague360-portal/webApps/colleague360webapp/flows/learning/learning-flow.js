define([], function() {
  'use strict';
  class LearningFlowModule {
    constructor() {}
  }
  return LearningFlowModule;
});
