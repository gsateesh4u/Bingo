define([], function() {
  'use strict';
  class MyTeamStartPageModule {
    constructor() {}
  }
  return MyTeamStartPageModule;
});
