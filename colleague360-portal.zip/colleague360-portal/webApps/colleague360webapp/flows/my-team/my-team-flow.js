define([], function() {
  'use strict';
  class MyTeamFlowModule {
    constructor() {}
  }
  return MyTeamFlowModule;
});
