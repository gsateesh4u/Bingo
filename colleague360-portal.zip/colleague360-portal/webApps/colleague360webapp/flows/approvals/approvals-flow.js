define([], function() {
  'use strict';
  class ApprovalsFlowModule {
    constructor() {}
  }
  return ApprovalsFlowModule;
});
