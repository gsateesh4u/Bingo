define([], function() {
  'use strict';
  class ApprovalsStartPageModule {
    constructor() {}
  }
  return ApprovalsStartPageModule;
});
