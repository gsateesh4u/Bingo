define([], function() {
  'use strict';
  class CompensationFlowModule {
    constructor() {}
  }
  return CompensationFlowModule;
});
