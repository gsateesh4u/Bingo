define([], function() {
  'use strict';
  class CompensationStartPageModule {
    constructor() {}
  }
  return CompensationStartPageModule;
});
