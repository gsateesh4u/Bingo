/**
 * Copyright (c) 2024, 2026 Oracle and/or its affiliates.
 */
define([], function () {
  'use strict';
  class PageModule {}
  return PageModule;
});
