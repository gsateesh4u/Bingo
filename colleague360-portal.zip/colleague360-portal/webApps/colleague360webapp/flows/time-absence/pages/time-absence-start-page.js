/**
 * Time & Absence Start Page Module
 */
define([], function() {
  'use strict';

  class TimeAbsenceStartPageModule {
    constructor() {}

    /**
     * Open time off request dialog
     */
    openRequestDialog() {
      document.getElementById('timeOffRequestDialog').open();
    }

    /**
     * Close time off request dialog
     */
    closeRequestDialog() {
      document.getElementById('timeOffRequestDialog').close();
    }
  }

  return TimeAbsenceStartPageModule;
});
