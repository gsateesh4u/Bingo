/**
 * Time & Absence Flow Module
 * Handles time tracking and absence management from Dayforce
 */
define([], function() {
  'use strict';

  class TimeAbsenceFlowModule {
    constructor() {}

    /**
     * Load time and absence data
     */
    loadTimeData() {
      return {
        timeBalances: {
          vacation: 80,
          sick: 40,
          personal: 16,
          floating: 8
        },
        pendingRequests: [
          {
            id: 'REQ001',
            type: 'Vacation',
            startDate: '2024-12-23',
            endDate: '2024-12-27',
            hours: 40,
            status: 'Pending',
            approver: 'Sarah Johnson'
          }
        ],
        recentEntries: [
          {
            date: '2024-11-15',
            regularHours: 8,
            overtime: 0,
            project: 'PROJ-001'
          }
        ]
      };
    }

    /**
     * Submit a time off request
     */
    submitTimeOffRequest(request) {
      console.log('Submitting time off request:', request);
      return { success: true, requestId: 'REQ' + Date.now() };
    }

    /**
     * Calculate business days between dates
     */
    calculateBusinessDays(startDate, endDate) {
      let count = 0;
      let current = new Date(startDate);
      const end = new Date(endDate);
      
      while (current <= end) {
        const dayOfWeek = current.getDay();
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
          count++;
        }
        current.setDate(current.getDate() + 1);
      }
      return count;
    }

    /**
     * Get status badge class
     */
    getStatusClass(status) {
      const statusClasses = {
        'Approved': 'oj-badge-success',
        'Pending': 'oj-badge-warning',
        'Denied': 'oj-badge-danger',
        'Cancelled': 'oj-badge-neutral'
      };
      return statusClasses[status] || 'oj-badge-neutral';
    }

    /**
     * Format hours to days display
     */
    formatHoursToDays(hours) {
      const days = hours / 8;
      return days === 1 ? '1 day' : days + ' days';
    }
  }

  return TimeAbsenceFlowModule;
});
