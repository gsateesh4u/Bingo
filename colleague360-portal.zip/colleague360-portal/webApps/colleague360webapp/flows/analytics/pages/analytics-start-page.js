define([], function() {
  'use strict';
  class AnalyticsStartPageModule {
    constructor() {}
  }
  return AnalyticsStartPageModule;
});
