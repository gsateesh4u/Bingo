define([], function() {
  'use strict';
  class AnalyticsFlowModule {
    constructor() {}
  }
  return AnalyticsFlowModule;
});
