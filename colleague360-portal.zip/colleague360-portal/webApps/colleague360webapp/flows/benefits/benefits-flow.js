/**
 * Benefits Flow Module
 * Handles benefits enrollment and management functionality
 */
define([], function() {
  'use strict';

  class BenefitsFlowModule {
    constructor() {}

    /**
     * Load benefits data from Alight connection
     */
    loadBenefitsData() {
      return {
        enrollmentPeriod: {
          status: 'Active',
          startDate: '2024-11-01',
          endDate: '2024-11-30'
        },
        benefitsSummary: {
          medical: {
            plan: 'Premium PPO',
            coverage: 'Family',
            monthlyPremium: 450,
            employerContribution: 350,
            employeeContribution: 100
          },
          dental: {
            plan: 'Standard Dental',
            coverage: 'Family',
            monthlyPremium: 85,
            employerContribution: 60,
            employeeContribution: 25
          },
          vision: {
            plan: 'Basic Vision',
            coverage: 'Employee + Spouse',
            monthlyPremium: 25,
            employerContribution: 15,
            employeeContribution: 10
          },
          life: {
            plan: '2x Salary',
            coverage: 'Employee',
            monthlyPremium: 0,
            employerContribution: 45,
            employeeContribution: 0
          }
        }
      };
    }

    /**
     * Calculate total monthly deductions
     */
    calculateTotalDeductions(benefits) {
      if (!benefits) return 0;
      
      let total = 0;
      Object.values(benefits).forEach(benefit => {
        if (benefit && benefit.employeeContribution) {
          total += benefit.employeeContribution;
        }
      });
      return total;
    }

    /**
     * Format currency for display
     */
    formatCurrency(amount) {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
      }).format(amount || 0);
    }

    /**
     * Get enrollment status badge class
     */
    getEnrollmentStatusClass(status) {
      const statusClasses = {
        'Active': 'oj-badge-success',
        'Pending': 'oj-badge-warning',
        'Closed': 'oj-badge-danger',
        'Upcoming': 'oj-badge-info'
      };
      return statusClasses[status] || 'oj-badge-neutral';
    }
  }

  return BenefitsFlowModule;
});
