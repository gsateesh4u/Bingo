/**
 * Benefits Start Page Module
 */
define([], function() {
  'use strict';

  class BenefitsStartPageModule {
    constructor() {}
  }

  return BenefitsStartPageModule;
});
