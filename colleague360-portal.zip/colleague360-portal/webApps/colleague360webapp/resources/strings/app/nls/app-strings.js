/**
 * Application strings for Colleague 360 Portal.
 * Root (default) bundle - used when no locale matches.
 */
define({
  root: {
    appTitle: 'Colleague 360 Portal',
    dashboard: 'Dashboard',
    myProfile: 'My Profile',
    myTeam: 'My Team',
    approvals: 'Approvals',
    payroll: 'Payroll',
    benefits: 'Benefits',
    timeAbsence: 'Time & Absence',
    learning: 'Learning',
    performance: 'Performance',
    compensation: 'Compensation',
    talent: 'Talent',
    recruitment: 'Recruitment',
    analytics: 'Analytics',
    quickLinks: 'Quick Links',
    notifications: 'Notifications',
    search: 'Search',
    signOut: 'Sign Out',
    settings: 'Settings'
  }
});
