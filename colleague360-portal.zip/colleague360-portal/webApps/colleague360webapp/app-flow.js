/**
 * Copyright (c) 2024, 2026 Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define([
  'ojs/ojresponsiveknockoututils',
  'ojs/ojresponsiveutils'
], function (ResponsiveKnockoutUtils, ResponsiveUtils) {
  'use strict';

  class AppModule {
    constructor(context) {
      this.eventHelper = context.getEventHelper();
      
      // Setup responsive utilities
      this.smQuery = ResponsiveKnockoutUtils.createMediaQueryObservable(
        ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.SM_ONLY)
      );
      this.mdQuery = ResponsiveKnockoutUtils.createMediaQueryObservable(
        ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.MD_UP)
      );
      this.lgQuery = ResponsiveKnockoutUtils.createMediaQueryObservable(
        ResponsiveUtils.getFrameworkQuery(ResponsiveUtils.FRAMEWORK_QUERY_KEY.LG_UP)
      );
    }

    /**
     * Check if current viewport is small (mobile)
     * @returns {boolean}
     */
    isSmallScreen() {
      return this.smQuery();
    }

    /**
     * Check if current viewport is medium or larger (tablet+)
     * @returns {boolean}
     */
    isMediumOrLarger() {
      return this.mdQuery();
    }

    /**
     * Check if current viewport is large or larger (desktop)
     * @returns {boolean}
     */
    isLargeOrLarger() {
      return this.lgQuery();
    }

    /**
     * Get user role based permissions
     * @param {string} role - User role (employee, manager, hr, executive)
     * @returns {object} Permission flags
     */
    getRolePermissions(role) {
      const permissions = {
        canViewTeam: false,
        canApprove: false,
        canAccessRecruitment: false,
        canAccessAnalytics: false,
        canAccessTalentManagement: false,
        canViewCompensation: false
      };

      switch (role) {
        case 'executive':
          permissions.canAccessAnalytics = true;
          permissions.canAccessTalentManagement = true;
          // Fall through to manager permissions
        case 'hr':
          permissions.canAccessRecruitment = true;
          permissions.canAccessAnalytics = true;
          // Fall through to manager permissions
        case 'manager':
          permissions.canViewTeam = true;
          permissions.canApprove = true;
          permissions.canViewCompensation = true;
          break;
        case 'employee':
        default:
          // Base permissions only
          break;
      }

      return permissions;
    }

    /**
     * Format date for display
     * @param {string} dateString - ISO date string
     * @param {string} format - Format type ('short', 'long', 'relative')
     * @returns {string} Formatted date
     */
    formatDate(dateString, format = 'short') {
      if (!dateString) return '';
      
      const date = new Date(dateString);
      const now = new Date();
      
      if (format === 'relative') {
        const diff = now - date;
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (days === 0) return 'Today';
        if (days === 1) return 'Yesterday';
        if (days < 7) return `${days} days ago`;
        if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
        return date.toLocaleDateString();
      }
      
      if (format === 'long') {
        return date.toLocaleDateString('en-US', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
      }
      
      return date.toLocaleDateString();
    }

    /**
     * Format currency for display
     * @param {number} amount - Amount to format
     * @param {string} currency - Currency code (default: USD)
     * @returns {string} Formatted currency
     */
    formatCurrency(amount, currency = 'USD') {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
      }).format(amount);
    }

    /**
     * Get navigation menu items based on user role
     * @param {string} role - User role
     * @returns {array} Menu items
     */
    getNavigationMenu(role) {
      const baseMenu = [
        { id: 'dashboard', label: 'Dashboard', icon: 'oj-ux-ico-home' },
        { id: 'my-profile', label: 'My Profile', icon: 'oj-ux-ico-contact' },
        { id: 'payroll', label: 'Payroll', icon: 'oj-ux-ico-currency' },
        { id: 'benefits', label: 'Benefits', icon: 'oj-ux-ico-heart' },
        { id: 'time-absence', label: 'Time & Absence', icon: 'oj-ux-ico-clock' },
        { id: 'learning', label: 'Learning', icon: 'oj-ux-ico-education' },
        { id: 'performance', label: 'Performance', icon: 'oj-ux-ico-trending-up' }
      ];

      const permissions = this.getRolePermissions(role);

      if (permissions.canViewTeam) {
        baseMenu.push({ id: 'my-team', label: 'My Team', icon: 'oj-ux-ico-people-group' });
      }

      if (permissions.canApprove) {
        baseMenu.push({ id: 'approvals', label: 'Approvals', icon: 'oj-ux-ico-check-circle', badge: true });
      }

      if (permissions.canViewCompensation) {
        baseMenu.push({ id: 'compensation', label: 'Compensation', icon: 'oj-ux-ico-money-bag' });
      }

      if (permissions.canAccessTalentManagement) {
        baseMenu.push({ id: 'talent', label: 'Talent', icon: 'oj-ux-ico-star' });
      }

      if (permissions.canAccessRecruitment) {
        baseMenu.push({ id: 'recruitment', label: 'Recruitment', icon: 'oj-ux-ico-person-add' });
      }

      if (permissions.canAccessAnalytics) {
        baseMenu.push({ id: 'analytics', label: 'Analytics', icon: 'oj-ux-ico-bar-chart' });
      }

      // Always add quick links at the end
      baseMenu.push({ id: 'quick-links', label: 'Quick Links', icon: 'oj-ux-ico-link' });

      return baseMenu;
    }

    /**
     * Toggle theme between light and dark
     * @param {string} currentTheme - Current theme
     * @returns {string} New theme
     */
    toggleTheme(currentTheme) {
      const newTheme = currentTheme === 'light' ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('colleague360-theme', newTheme);
      return newTheme;
    }

    /**
     * Load saved theme preference
     * @returns {string} Saved theme or 'light'
     */
    loadThemePreference() {
      const savedTheme = localStorage.getItem('colleague360-theme') || 'light';
      document.documentElement.setAttribute('data-theme', savedTheme);
      return savedTheme;
    }

    /**
     * Fire application event
     * @param {string} eventName - Name of the event
     * @param {object} payload - Event payload
     */
    fireEvent(eventName, payload) {
      this.eventHelper.fireCustomEvent(eventName, payload);
    }
  }

  return AppModule;
});
