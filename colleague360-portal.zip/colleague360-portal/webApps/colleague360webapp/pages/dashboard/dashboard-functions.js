/**
 * Colleague 360 Portal - Dashboard Page Functions
 * Helper functions for the dashboard page
 */

define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  /**
   * Format date to localized string
   * @param {string|Date} dateValue - Date to format
   * @returns {string} Formatted date string
   */
  PageModule.prototype.formatDate = function(dateValue) {
    if (!dateValue) return '';
    const date = new Date(dateValue);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  /**
   * Format currency value
   * @param {number} value - Currency value
   * @returns {string} Formatted currency string
   */
  PageModule.prototype.formatCurrency = function(value) {
    if (value === null || value === undefined) return '0.00';
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  /**
   * Check if user is a manager
   * @param {string} role - User role
   * @returns {boolean} True if user is a manager
   */
  PageModule.prototype.isManager = function(role) {
    return role === 'manager' || role === 'hr' || role === 'executive';
  };

  /**
   * Check if user is HR
   * @param {string} role - User role
   * @returns {boolean} True if user is HR
   */
  PageModule.prototype.isHR = function(role) {
    return role === 'hr';
  };

  /**
   * Get icon for action source
   * @param {string} source - Action source system
   * @returns {string} Icon URL
   */
  PageModule.prototype.getSourceIcon = function(source) {
    const iconMap = {
      'Oracle HCM': 'resources/images/icons/oracle-hcm.png',
      'ADP': 'resources/images/icons/adp.png',
      'Ceridian': 'resources/images/icons/ceridian.png',
      'Dayforce': 'resources/images/icons/dayforce.png',
      'Alight': 'resources/images/icons/alight.png',
      'LTIA': 'resources/images/icons/ltia.png',
      'Amex Actions': 'resources/images/icons/amex.png',
      'default': 'resources/images/icons/default-action.png'
    };
    return iconMap[source] || iconMap['default'];
  };

  /**
   * Aggregate KPI data from multiple sources
   * @param {Object} ptoData - PTO balance data
   * @param {Object} payrollData - Payroll data
   * @param {Object} learningData - Learning hours data
   * @param {Object} performanceData - Performance rating data
   * @param {Object} benefitsData - Benefits enrollment data
   * @param {Object} managerData - Manager specific KPIs
   * @returns {Object} Aggregated KPI object
   */
  PageModule.prototype.aggregateKPIData = function(ptoData, payrollData, learningData, performanceData, benefitsData, managerData) {
    return {
      ptoBalance: ptoData?.body?.balance || 0,
      nextPayAmount: payrollData?.body?.netPay || 0,
      nextPayDate: payrollData?.body?.payDate || '',
      learningHours: learningData?.body?.hoursCompleted || 0,
      performanceRating: performanceData?.body?.overallRating || 0,
      benefitsEnrollmentOpen: benefitsData?.body?.isEnrollmentOpen || false,
      enrollmentDeadline: benefitsData?.body?.deadline || '',
      teamSize: managerData?.body?.directReportCount || 0,
      pendingApprovals: managerData?.body?.pendingApprovals || 0
    };
  };

  /**
   * Merge and sort actions from multiple sources
   * @param {Object} oracleActions - Oracle HCM actions
   * @param {Object} amexActions - Amex actions
   * @param {Object} dayforceActions - Dayforce actions
   * @returns {Object} Merged and sorted actions
   */
  PageModule.prototype.mergeAndSortActions = function(oracleActions, amexActions, dayforceActions) {
    const allActions = [];
    
    // Process Oracle HCM actions
    if (oracleActions?.body?.items) {
      oracleActions.body.items.forEach(action => {
        allActions.push({
          ...action,
          source: 'Oracle HCM',
          actionUrl: action.deepLink || `oraclehcm://action/${action.id}`
        });
      });
    }
    
    // Process Amex actions
    if (amexActions?.body?.items) {
      amexActions.body.items.forEach(action => {
        allActions.push({
          ...action,
          source: 'Amex Actions',
          actionUrl: action.deepLink || `amex://approval/${action.id}`
        });
      });
    }
    
    // Process Dayforce actions
    if (dayforceActions?.body?.items) {
      dayforceActions.body.items.forEach(action => {
        allActions.push({
          ...action,
          source: 'Dayforce',
          actionUrl: action.deepLink || `dayforce://request/${action.id}`
        });
      });
    }
    
    // Sort by priority and due date
    const priorityOrder = { 'high': 1, 'medium': 2, 'low': 3 };
    allActions.sort((a, b) => {
      const priorityDiff = (priorityOrder[a.priority] || 3) - (priorityOrder[b.priority] || 3);
      if (priorityDiff !== 0) return priorityDiff;
      return new Date(a.dueDate) - new Date(b.dueDate);
    });
    
    return { items: allActions };
  };

  /**
   * Enrich team data with status information
   * @param {Object} teamData - Raw team data from API
   * @returns {Object} Enriched team data with insights
   */
  PageModule.prototype.enrichTeamData = function(teamData) {
    const today = new Date();
    const members = (teamData?.items || []).map(member => {
      const isOutToday = member.absences?.some(absence => {
        const start = new Date(absence.startDate);
        const end = new Date(absence.endDate);
        return today >= start && today <= end;
      }) || false;
      
      const hasBirthday = member.birthDate ? 
        this.isSameMonthDay(new Date(member.birthDate), today) : false;
      
      const hireDate = new Date(member.hireDate);
      const hasAnniversary = this.isSameMonthDay(hireDate, today) && 
        hireDate.getFullYear() !== today.getFullYear();
      
      return {
        ...member,
        isOutToday,
        hasBirthday,
        hasAnniversary
      };
    });
    
    const insights = {
      outToday: members.filter(m => m.isOutToday).length,
      pendingTimeoff: teamData?.pendingTimeoffCount || 0,
      goalsOverdue: teamData?.overdueGoalsCount || 0
    };
    
    return { members, insights };
  };

  /**
   * Check if two dates have the same month and day
   * @param {Date} date1 - First date
   * @param {Date} date2 - Second date
   * @returns {boolean} True if same month and day
   */
  PageModule.prototype.isSameMonthDay = function(date1, date2) {
    return date1.getMonth() === date2.getMonth() && 
           date1.getDate() === date2.getDate();
  };

  /**
   * Get action by ID from actions array
   * @param {string} actionId - Action ID
   * @param {Array} actions - Actions array
   * @returns {Object} Action object
   */
  PageModule.prototype.getActionById = function(actionId, actions) {
    return actions.find(action => action.id === actionId) || null;
  };

  return PageModule;
});
