/**
 * Shell page view model - delegates to shell-functions and provides navigation.
 * Required so Cookbook template HTML can use $page.functions (closeSearch, navigateToFlow, etc.).
 */
define(['./shell-functions'], function (shellFunctions) {
  'use strict';

  class PageModule {
    constructor(context) {
      this.context = context;
      this._shellFunctions = shellFunctions;
    }

    closeSearch(pageContext) {
      this._shellFunctions.closeSearch(pageContext || this.context.getPage());
    }

    handleSearch(query) {
      this._shellFunctions.handleSearch(query);
    }

    navigateToFlow(flowId) {
      const page = this.context.getPage();
      if (page && page.application && typeof page.application.router !== 'undefined' && page.application.router.go) {
        page.application.router.go(flowId);
      } else {
        this._shellFunctions.navigateToFlow(flowId);
      }
    }

    markAllRead() {
      this._shellFunctions.markAllRead();
    }

    loadSavedTheme() {
      return this._shellFunctions.loadSavedTheme();
    }

    applyTheme(theme) {
      this._shellFunctions.applyTheme(theme);
    }

    initKeyboardShortcuts(pageContext) {
      this._shellFunctions.initKeyboardShortcuts(pageContext || this.context.getPage());
    }
  }

  return PageModule;
});
