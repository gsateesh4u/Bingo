/**
 * Colleague 360 Portal - Shell Page Functions
 * Handles universal search, notifications, FAB, theme toggle
 */

'use strict';

define([], function() {
  
  /**
   * Initialize keyboard shortcuts
   */
  function initKeyboardShortcuts(page) {
    document.addEventListener('keydown', function(e) {
      // Ctrl+K or Cmd+K to open search
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        page.variables.searchVisible = true;
        setTimeout(() => {
          document.getElementById('universal-search-input')?.focus();
        }, 100);
      }
      
      // ESC to close overlays
      if (e.key === 'Escape') {
        page.variables.searchVisible = false;
        page.variables.notificationPanelOpen = false;
        page.variables.fabExpanded = false;
      }
    });
  }
  
  /**
   * Toggle dark/light theme
   */
  function toggleTheme(page) {
    const currentTheme = page.variables.theme || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    page.variables.theme = newTheme;
    
    // Persist preference
    localStorage.setItem('c360-theme', newTheme);
    
    // Apply to document
    document.documentElement.setAttribute('data-theme', newTheme);
  }
  
  /**
   * Load saved theme preference
   */
  function loadThemePreference() {
    const savedTheme = localStorage.getItem('c360-theme') || localStorage.getItem('colleague360-theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    return savedTheme;
  }

  /** Alias for shell-page compatibility */
  function loadSavedTheme() {
    return loadThemePreference();
  }

  /**
   * Apply theme to document (called from chain with theme param)
   */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme || 'light');
    localStorage.setItem('colleague360-theme', theme || 'light');
    localStorage.setItem('c360-theme', theme || 'light');
  }

  function closeSearch(pageContext) {
    if (pageContext && pageContext.variables) pageContext.variables.searchVisible = false;
  }

  function handleSearch(query) {
    if (typeof console !== 'undefined' && console.log) console.log('Searching for:', query);
  }

  function navigateToFlow(flowId) {
    if (typeof console !== 'undefined' && console.log) console.log('Navigate to:', flowId);
  }

  function markAllRead() {
    if (typeof console !== 'undefined' && console.log) console.log('Marking all notifications as read');
  }

  function addNotificationMessage(message) {
    if (typeof console !== 'undefined' && console.log) console.log('Add notification:', message);
  }

  function removeNotificationMessage(message) {
    if (typeof console !== 'undefined' && console.log) console.log('Remove notification:', message);
  }
  
  /**
   * Search function - filters across categories
   */
  function performSearch(query, filter) {
    const results = {
      people: [],
      pages: [],
      actions: [],
      documents: [],
      total: 0
    };
    
    if (!query || query.length < 2) {
      return results;
    }
    
    const lowerQuery = query.toLowerCase();
    
    // Search pages
    const pages = [
      { pageId: 'dashboard', title: 'Dashboard', icon: 'oj-ux-ico-home', description: 'Main dashboard overview' },
      { pageId: 'my-profile', title: 'My Profile', icon: 'oj-ux-ico-user', description: 'View and edit your profile' },
      { pageId: 'payroll', title: 'Payroll', icon: 'oj-ux-ico-dollar-circle', description: 'Pay statements and tax forms' },
      { pageId: 'benefits', title: 'Benefits', icon: 'oj-ux-ico-heart', description: 'Health, dental, vision benefits' },
      { pageId: 'time-absence', title: 'Time & Absence', icon: 'oj-ux-ico-calendar', description: 'Request time off, view balances' },
      { pageId: 'learning', title: 'Learning', icon: 'oj-ux-ico-education', description: 'Courses and certifications' },
      { pageId: 'performance', title: 'Performance', icon: 'oj-ux-ico-trending-up', description: 'Goals and reviews' },
      { pageId: 'compensation', title: 'Compensation', icon: 'oj-ux-ico-coins', description: 'Salary and total rewards' },
      { pageId: 'talent', title: 'Talent & Career', icon: 'oj-ux-ico-star', description: 'Career development' },
      { pageId: 'analytics', title: 'People Analytics', icon: 'oj-ux-ico-chart-line', description: 'Workforce metrics and insights' },
      { pageId: 'approvals', title: 'Approvals', icon: 'oj-ux-ico-check-circle', description: 'Pending approvals' },
      { pageId: 'my-team', title: 'My Team', icon: 'oj-ux-ico-people', description: 'Team members and org chart' }
    ];
    
    results.pages = pages.filter(p => 
      p.title.toLowerCase().includes(lowerQuery) ||
      p.description.toLowerCase().includes(lowerQuery)
    );
    
    // Search actions
    const actions = [
      { actionId: 'request-time-off', title: 'Request Time Off', icon: 'oj-ux-ico-calendar-plus' },
      { actionId: 'view-payslip', title: 'View Latest Payslip', icon: 'oj-ux-ico-document' },
      { actionId: 'update-goals', title: 'Update Goals', icon: 'oj-ux-ico-target' },
      { actionId: 'submit-expense', title: 'Submit Expense Report', icon: 'oj-ux-ico-receipt' },
      { actionId: 'request-feedback', title: 'Request Feedback', icon: 'oj-ux-ico-chat-bubble' },
      { actionId: 'enroll-course', title: 'Enroll in Course', icon: 'oj-ux-ico-book' },
      { actionId: 'update-profile', title: 'Update Profile', icon: 'oj-ux-ico-user-edit' },
      { actionId: 'view-benefits', title: 'View Benefits Summary', icon: 'oj-ux-ico-heart' },
      { actionId: 'download-tax-forms', title: 'Download Tax Forms', icon: 'oj-ux-ico-download' }
    ];
    
    results.actions = actions.filter(a => 
      a.title.toLowerCase().includes(lowerQuery)
    );
    
    results.total = results.people.length + results.pages.length + 
                   results.actions.length + results.documents.length;
    
    return results;
  }
  
  /**
   * Check if user is Manager or HR
   */
  function isManagerOrHR(role) {
    return role === 'Manager' || role === 'HR' || role === 'Executive';
  }
  
  /**
   * Check if user is HR
   */
  function isHR(role) {
    return role === 'HR';
  }
  
  /**
   * Format relative time (e.g., "2 hours ago")
   */
  function getRelativeTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    
    return date.toLocaleDateString();
  }
  
  /**
   * Group notifications by priority
   */
  function groupNotifications(notifications) {
    return {
      all: notifications,
      urgent: notifications.filter(n => n.priority === 'urgent'),
      action: notifications.filter(n => n.priority === 'action'),
      fyi: notifications.filter(n => n.priority === 'fyi')
    };
  }
  
  /**
   * Handle quick action execution
   */
  function executeQuickAction(action, page) {
    const actionRoutes = {
      'request-time-off': 'time-absence',
      'view-payslip': 'payroll',
      'update-profile': 'my-profile',
      'log-learning': 'learning',
      'approve-requests': 'approvals',
      'team-calendar': 'my-team',
      'give-feedback': 'performance',
      'new-hire': 'recruitment',
      'run-report': 'analytics'
    };
    
    const route = actionRoutes[action];
    if (route) {
      page.variables.fabExpanded = false;
      // Navigate to page
      page.application.router.go(route);
    }
  }
  
  return {
    initKeyboardShortcuts,
    toggleTheme,
    loadThemePreference,
    loadSavedTheme,
    applyTheme,
    performSearch,
    closeSearch,
    handleSearch,
    navigateToFlow,
    markAllRead,
    addNotificationMessage,
    removeNotificationMessage,
    isManagerOrHR,
    isHR,
    getRelativeTime,
    groupNotifications,
    executeQuickAction
  };
});
