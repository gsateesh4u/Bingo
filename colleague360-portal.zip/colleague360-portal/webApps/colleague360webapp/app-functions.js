/**
 * Colleague 360 Portal - Application Functions
 * Shared utility functions for the application
 */

define([], function() {
  'use strict';

  var AppModule = function AppModule() {};

  /**
   * Get user initials from display name
   * @param {string} displayName - Full name of the user
   * @returns {string} Initials (up to 2 characters)
   */
  AppModule.prototype.getInitials = function(displayName) {
    if (!displayName) return '?';
    const names = displayName.trim().split(' ');
    if (names.length === 1) {
      return names[0].charAt(0).toUpperCase();
    }
    return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
  };

  /**
   * Format date to localized string
   * @param {string|Date} dateValue - Date to format
   * @param {string} format - Format type: 'short', 'long', 'relative'
   * @returns {string} Formatted date string
   */
  AppModule.prototype.formatDate = function(dateValue, format = 'short') {
    if (!dateValue) return '';
    
    const date = new Date(dateValue);
    
    if (format === 'relative') {
      return this.getRelativeTime(date);
    }
    
    const options = format === 'long' 
      ? { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }
      : { year: 'numeric', month: 'short', day: 'numeric' };
    
    return date.toLocaleDateString('en-US', options);
  };

  /**
   * Get relative time string (e.g., "2 hours ago")
   * @param {Date} date - Date to compare
   * @returns {string} Relative time string
   */
  AppModule.prototype.getRelativeTime = function(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    
    return this.formatDate(date, 'short');
  };

  /**
   * Format currency value
   * @param {number} value - Currency value
   * @param {string} currency - Currency code (default: USD)
   * @returns {string} Formatted currency string
   */
  AppModule.prototype.formatCurrency = function(value, currency = 'USD') {
    if (value === null || value === undefined) return '$0.00';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(value);
  };

  /**
   * Format number with commas
   * @param {number} value - Number to format
   * @returns {string} Formatted number string
   */
  AppModule.prototype.formatNumber = function(value) {
    if (value === null || value === undefined) return '0';
    return new Intl.NumberFormat('en-US').format(value);
  };

  /**
   * Check if user has a specific role
   * @param {string} userRole - User's role
   * @param {string|string[]} allowedRoles - Role(s) to check
   * @returns {boolean} True if user has the role
   */
  AppModule.prototype.hasRole = function(userRole, allowedRoles) {
    if (Array.isArray(allowedRoles)) {
      return allowedRoles.includes(userRole);
    }
    return userRole === allowedRoles;
  };

  /**
   * Check if user is a manager
   * @param {string} userRole - User's role
   * @returns {boolean} True if user is a manager
   */
  AppModule.prototype.isManager = function(userRole) {
    return ['manager', 'senior_manager', 'director', 'vp', 'executive', 'hr'].includes(userRole);
  };

  /**
   * Check if user is HR
   * @param {string} userRole - User's role
   * @returns {boolean} True if user is HR
   */
  AppModule.prototype.isHR = function(userRole) {
    return ['hr', 'hr_manager', 'hr_admin'].includes(userRole);
  };

  /**
   * Check if user is manager or HR
   * @param {string} userRole - User's role
   * @returns {boolean} True if user is manager or HR
   */
  AppModule.prototype.isManagerOrHR = function(userRole) {
    return this.isManager(userRole) || this.isHR(userRole);
  };

  /**
   * Get external URL configuration
   * @param {string} urlKey - Key for the URL
   * @returns {string} Full URL
   */
  AppModule.prototype.getExternalUrl = function(urlKey) {
    const urlMap = {
      // Oracle HCM URLs
      'oracle-hcm-home': 'https://your-tenant.oraclecloud.com/fscmUI/faces/FuseWelcome',
      'oracle-hcm-me': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FndOverview?fndGlobalItemNodeId=itemNode_my_information',
      'oracle-hcm-directory': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FuseDirectory',
      'oracle-hcm-learning': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FuseOverview?fndGlobalItemNodeId=itemNode_learning_center',
      'oracle-hcm-performance': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FuseOverview?fndGlobalItemNodeId=itemNode_performance_management',
      'oracle-hcm-talent': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FuseOverview?fndGlobalItemNodeId=itemNode_career_development',
      'oracle-hcm-recruiting': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FuseOverview?fndGlobalItemNodeId=itemNode_recruiting',
      'oracle-hcm-compensation': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FuseOverview?fndGlobalItemNodeId=itemNode_compensation',
      'oracle-hcm-core': 'https://your-tenant.oraclecloud.com/hcmUI/faces/FuseOverview?fndGlobalItemNodeId=itemNode_workforce_management',
      
      // Payroll URLs
      'adp-home': 'https://workforcenow.adp.com',
      'adp-payroll': 'https://workforcenow.adp.com/payroll',
      'ceridian-home': 'https://your-tenant.dayforcehcm.com',
      'ceridian-payroll': 'https://your-tenant.dayforcehcm.com/payroll',
      'ltia-portal': 'https://ltia-portal.yourcompany.com',
      
      // Time & Absence URLs
      'dayforce-time': 'https://your-tenant.dayforcehcm.com/time',
      'dayforce-absence': 'https://your-tenant.dayforcehcm.com/absence',
      
      // Benefits URLs
      'alight-benefits': 'https://benefits.alight.com/your-company',
      'alight-401k': 'https://benefits.alight.com/your-company/retirement',
      'alight-hsa': 'https://benefits.alight.com/your-company/hsa',
      'alight-life': 'https://benefits.alight.com/your-company/life',
      
      // Expense URLs
      'amex-actions': 'https://business.americanexpress.com',
      'concur-travel': 'https://your-company.concursolutions.com',
      
      // Company Resources
      'company-intranet': 'https://intranet.yourcompany.com',
      'it-helpdesk': 'https://helpdesk.yourcompany.com',
      'hr-help': 'https://hr.yourcompany.com/help',
      'employee-handbook': 'https://intranet.yourcompany.com/handbook'
    };
    
    return urlMap[urlKey] || '#';
  };

  /**
   * Deep link to external application with context
   * @param {string} app - Application identifier
   * @param {string} action - Action to perform
   * @param {Object} params - Parameters for the deep link
   * @returns {string} Deep link URL
   */
  AppModule.prototype.buildDeepLink = function(app, action, params) {
    const baseUrl = this.getExternalUrl(app);
    const queryParams = new URLSearchParams(params).toString();
    return queryParams ? `${baseUrl}?${queryParams}` : baseUrl;
  };

  /**
   * Truncate text to specified length
   * @param {string} text - Text to truncate
   * @param {number} maxLength - Maximum length
   * @returns {string} Truncated text with ellipsis
   */
  AppModule.prototype.truncateText = function(text, maxLength = 100) {
    if (!text || text.length <= maxLength) return text;
    return text.substring(0, maxLength - 3) + '...';
  };

  /**
   * Generate a unique ID
   * @returns {string} Unique identifier
   */
  AppModule.prototype.generateUniqueId = function() {
    return 'id_' + Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  /**
   * Parse error response and return user-friendly message
   * @param {Object} error - Error object
   * @returns {string} User-friendly error message
   */
  AppModule.prototype.parseErrorMessage = function(error) {
    if (error.body && error.body.message) {
      return error.body.message;
    }
    if (error.message) {
      return error.message;
    }
    return 'An unexpected error occurred. Please try again later.';
  };

  /**
   * Store user preference in local storage
   * @param {string} key - Preference key
   * @param {any} value - Preference value
   */
  AppModule.prototype.setUserPreference = function(key, value) {
    try {
      const preferences = JSON.parse(localStorage.getItem('c360_preferences') || '{}');
      preferences[key] = value;
      localStorage.setItem('c360_preferences', JSON.stringify(preferences));
    } catch (e) {
      console.error('Failed to save preference:', e);
    }
  };

  /**
   * Get user preference from local storage
   * @param {string} key - Preference key
   * @param {any} defaultValue - Default value if not found
   * @returns {any} Preference value
   */
  AppModule.prototype.getUserPreference = function(key, defaultValue = null) {
    try {
      const preferences = JSON.parse(localStorage.getItem('c360_preferences') || '{}');
      return preferences[key] !== undefined ? preferences[key] : defaultValue;
    } catch (e) {
      console.error('Failed to get preference:', e);
      return defaultValue;
    }
  };

  return AppModule;
});
