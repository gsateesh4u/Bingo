# Colleague 360 Portal - Oracle VBCS Project

## Overview

Colleague 360 is a unified HR experience portal built on Oracle Visual Builder Cloud Service (VBCS). It provides employees, managers, and HR personnel with a holistic view of all colleague applications in one centralized dashboard.

### Template & Components

The app uses the **Oracle Visual Builder Cookbook** dashboard template pattern and Cookbook-style components:

- **Shell**: [Cookbook Dashboard Template](https://vbcookbook.oracle.com/?page=shell&shell=dashboard-template) — `oj-web-applayout-page`, `oj-web-applayout-header`, `oj-drawer-layout`, `oj-navigation-list` with `oj-option`, header with `oj-flex-bar`.
- **Default shell page**: `shell` (Cookbook drawer layout at `pages/shell/`). The `shell-page` files at the root of `pages/` are optional and not used as default to avoid 404s.
- **Components**: Redwood/JET components as in the [Cookbook components list](https://vbcookbook.oracle.com/?filter=all) — `oj-button`, `oj-badge`, `oj-avatar`, `oj-list-view`, `oj-list-item-layout`, `oj-input-search`, `oj-messages`, `oj-menu-button`, `oj-typography-*` and `oj-flex` layout classes.

## Features

### Dashboard
- **KPI Cards**: PTO balance, next paycheck, learning hours, performance rating
- **Actions Required**: Aggregated pending actions from all integrated systems
- **My Team** (Managers): Quick view of direct reports with status indicators
- **Quick Links**: Fast access to frequently used applications
- **Announcements**: Company-wide communications

### Integrated Systems

| System | Purpose | Integration Type |
|--------|---------|------------------|
| Oracle HCM Cloud | Core HR, Learning, Performance, Talent, Recruiting, Compensation | REST API |
| ADP Workforce Now | Payroll, Pay Statements, Tax Forms | REST API |
| Ceridian Dayforce | Payroll, Workforce Management | REST API |
| Dayforce | Time Tracking, Absence Management | REST API |
| LTIA Portal | Long-Term Incentive Awards | REST API |
| Alight | Benefits, 401(k), HSA/FSA | REST API |
| Amex Actions | Corporate Card, Expense Management | REST API |

## Project Structure

```
colleague360-portal/
├── visual-application.json          # Main application configuration
├── services/                         # Service connection definitions
│   ├── oracle-hcm-connection.json
│   ├── adp-payroll-connection.json
│   ├── ceridian-payroll-connection.json
│   ├── dayforce-absence-connection.json
│   ├── ltia-incentives-connection.json
│   ├── alight-benefits-connection.json
│   └── amex-actions-connection.json
└── webApps/
    └── colleague360webapp/
        ├── app-flow.json             # Application flow configuration
        ├── app-functions.js          # Shared utility functions
        ├── pages/
        │   ├── shell/                # Main application shell
        │   ├── dashboard/            # Main dashboard page
        │   ├── my-profile/           # Employee profile
        │   ├── my-team/              # Team management (managers)
        │   ├── approvals/            # Approvals & actions center
        │   ├── payroll/              # Payroll information
        │   ├── benefits/             # Benefits management
        │   ├── time-absence/         # Time & absence tracking
        │   ├── learning/             # Learning management
        │   ├── performance/          # Performance management
        │   ├── compensation/         # Compensation details
        │   ├── talent/               # Talent management
        │   ├── recruitment/          # Recruitment (HR only)
        │   └── quick-links/          # Application links directory
        └── resources/
            ├── css/
            │   └── app.css           # Application styles
            └── images/
                └── icons/            # Application icons
```

## Setup Instructions

### Prerequisites
- Oracle Cloud Account with VBCS access
- Service accounts for each integrated system
- OAuth2 credentials for API authentication

### Configuration Steps

1. **Import Project**
   - Log into Oracle Visual Builder
   - Create a new application
   - Import the project files

2. **Configure Service Connections**
   - Update base URLs in each service connection file
   - Configure OAuth2 credentials in VBCS
   - Test each connection

3. **Update External URLs**
   - Edit `app-functions.js`
   - Update the `urlMap` object with your organization's actual URLs

4. **Configure Authentication**
   - Set up Oracle IDCS integration
   - Configure user role mappings

5. **Deploy**
   - Stage the application for testing
   - Publish to production

## User Roles

| Role | Access Level |
|------|-------------|
| Employee | Personal info, own KPIs, requests |
| Manager | + Team management, approvals |
| HR | + Full employee access, recruiting |
| Executive | + Organization-wide analytics |

## Customization

### Adding New Integrations

1. Create a new service connection JSON file in `/services/`
2. Add the connection reference to `visual-application.json`
3. Create action chains to call the new endpoints
4. Update the dashboard to display new data

### Theming

The application uses Oracle's Redwood theme with custom CSS variables defined in `app.css`. Modify the CSS custom properties to match your organization's branding:

```css
:root {
  --c360-primary: #your-primary-color;
  --c360-secondary: #your-secondary-color;
  /* ... */
}
```

## Security Considerations

- All API calls require valid OAuth2 tokens
- Sensitive data (SSN, salary) is masked by default
- Role-based access control enforced at page and component level
- Audit logging for all data access

## Troubleshooting

### No styles / bindings show as raw text (e.g. `[[ $application.variables... ]]`)

1. **Run from VB Studio Preview**  
   Always use **Run** or **Preview** from the Oracle Visual Builder designer (not by opening `index.html` directly). The preview server injects the Redwood theme and the VB runtime that evaluates bindings.

2. **Check preview URL**  
   The URL should look like:  
   `.../ic/builder/design/<workspace>/.../preview/webApps/colleague360webapp/`  
   So the app is served by the VB runtime and theme/CSS paths resolve correctly.

3. **App CSS**  
   The project includes fallback links in `index.html` for `app.css` and `redwood-overrides.css`, and fallback utility styles in `redwood-overrides.css` so layout and typography work even if the theme inject fails. If you still see no styles, confirm that `webApps/colleague360webapp/resources/css/app.css` and `redwood-overrides.css` exist and that no 404s appear for them in the browser Network tab.

4. **Bindings**  
   If expressions still appear as literal `[[ ... ]]`, the VB runtime is not processing the page. Ensure you are using the designer’s **Preview** and that the workspace and app are published/up to date. Re-publish or refresh the preview and try again.

## Support

For technical support, contact the HR Technology team.

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-02-05 | Initial release |

## License

Internal use only. © 2026 Your Company Name.
